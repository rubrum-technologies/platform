using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("MyCompanyName.MyProjectName.EntityFrameworkCore.Tests")]
