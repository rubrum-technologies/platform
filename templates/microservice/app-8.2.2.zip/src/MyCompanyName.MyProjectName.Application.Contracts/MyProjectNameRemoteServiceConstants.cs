namespace MyCompanyName.MyProjectName;

public static class MyProjectNameRemoteServiceConstants
{
    public const string RemoteServiceName = "MyProjectName";

    public const string ModuleName = "myProjectName";
}
