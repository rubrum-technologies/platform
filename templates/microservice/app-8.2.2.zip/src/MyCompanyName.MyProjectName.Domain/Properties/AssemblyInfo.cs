using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("MyCompanyName.MyProjectName.Domain.Tests")]
[assembly: InternalsVisibleTo("MyCompanyName.MyProjectName.TestBase")]
