namespace MyCompanyName.MyProjectName;

public class MyProjectNameEntityFrameworkCoreTestBase
    : MyProjectNameTestBase<MyProjectNameEntityFrameworkCoreTestModule>;
